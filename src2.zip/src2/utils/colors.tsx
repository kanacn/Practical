export default {
  WHITE: 'white',
  gray: '#7E7B7B',
  black: '#000000',
  primary: '#398DD5',
};
