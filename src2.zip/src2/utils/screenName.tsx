export default {
  homeScreen: 'homeScreen',
  displayScreen: 'displayScreen',
  captureScreen: 'captureScreen',
  mainTab: 'mainTab',
};
